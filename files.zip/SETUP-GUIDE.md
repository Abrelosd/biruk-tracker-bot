# 🚀 How to Deploy Your Telegram Bot (Free, No Coding Needed)

## What you need first
Before starting, make sure you have:
- ✅ Your Bot Token: `8714914060:AAET07qw3Z_CJnyLEEwJjooTCPxuz03Tf2Q`
- ✅ Your JSONBin Master Key (from jsonbin.io)
- ✅ Your JSONBin Bin ID (shown in the web app after connecting)

---

## Step 1 — Create a GitHub Account (free)
1. Go to **github.com** and sign up for free
2. Click **New Repository** (the green button)
3. Name it `biruk-tracker-bot`
4. Make sure it's set to **Public**
5. Click **Create Repository**

---

## Step 2 — Upload Your Bot Files
1. On your new repository page, click **uploading an existing file**
2. Upload these two files:
   - `bot.py`
   - `requirements.txt`
3. Click **Commit changes**

---

## Step 3 — Deploy on Railway (free hosting)
1. Go to **railway.app** and click **Login with GitHub**
2. Click **New Project** → **Deploy from GitHub repo**
3. Select your `biruk-tracker-bot` repository
4. Railway will detect it automatically — click **Deploy**

---

## Step 4 — Add Your Secret Keys
This is important! In Railway:
1. Click on your project → go to **Variables** tab
2. Add these 3 variables one by one:

| Variable Name | Value |
|--------------|-------|
| `BOT_TOKEN` | `8714914060:AAET07qw3Z_CJnyLEEwJjooTCPxuz03Tf2Q` |
| `JSONBIN_KEY` | Your JSONBin Master Key |
| `JSONBIN_BIN` | Your Bin ID from the web app |

3. Click **Deploy** again after adding variables

---

## Step 5 — Test Your Bot!
1. Open Telegram and search for **@SDbrukbot**
2. Send `/start` — you should see the welcome message
3. Try `/add 25000 agent deposit`
4. Try `/balance`
5. Share the bot with Biruk — he can use the same commands!

---

## Bot Commands Cheat Sheet

| Command | Example | What it does |
|---------|---------|--------------|
| `/start` | `/start` | Shows help menu |
| `/add` | `/add 25000 agent deposit` | Adds money |
| `/sub` | `/sub 6860 withdrawal` | Subtracts money |
| `/balance` | `/balance` | Shows current balance |
| `/history` | `/history` | Shows last 10 transactions |
| `/clear` | `/clear` | Clears all history |

---

## How it all works together

```
Abrham's phone (web app) ──┐
                            ├──► JSONBin Storage ◄──► Telegram Bot (@SDbrukbot)
Biruk's phone (web app)  ──┘
```

Both the web app AND the Telegram bot read/write from the same JSONBin storage.
So whether you use the web app or Telegram, the balance is always the same! ✅

---

## Need help? 
Just ask Claude and paste any error message you see.
